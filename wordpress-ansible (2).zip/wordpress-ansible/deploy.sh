#!/usr/bin/env bash
# =============================================================================
#  deploy.sh — Lance les conteneurs Docker et installe WordPress via Ansible
# =============================================================================
set -e

BLUE='\033[0;34m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'

info()    { echo -e "${BLUE}[INFO]${NC} $*"; }
success() { echo -e "${GREEN}[OK]${NC} $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }

# ── Vérifications préalables ──────────────────────────────────────────────────
command -v docker        >/dev/null 2>&1 || error "Docker non trouvé. Installez Docker."
command -v ansible-playbook >/dev/null 2>&1 || error "Ansible non trouvé. Installez Ansible."
command -v sshpass       >/dev/null 2>&1 || warn  "sshpass non trouvé (apt install sshpass). Requis pour SSH par mot de passe."

echo ""
echo "=============================================="
echo "  DÉPLOIEMENT WORDPRESS — Debian 13 & RedHat"
echo "=============================================="
echo ""

# ── Étape 1 : Build & lancement des conteneurs ───────────────────────────────
info "Étape 1/4 — Build et lancement des conteneurs Docker..."
docker compose up -d --build

info "Attente du démarrage SSH dans les conteneurs (15s)..."
sleep 15

# ── Vérification connectivité SSH ─────────────────────────────────────────────
info "Vérification SSH Debian (172.20.0.10)..."
sshpass -p ansible ssh -o StrictHostKeyChecking=no -o ConnectTimeout=10 \
  ansible@172.20.0.10 "echo 'Debian OK'" || warn "SSH Debian pas encore prêt, attente supplémentaire..."
sleep 5

info "Vérification SSH RedHat (172.20.0.11)..."
sshpass -p ansible ssh -o StrictHostKeyChecking=no -o ConnectTimeout=10 \
  ansible@172.20.0.11 "echo 'RedHat OK'" || warn "SSH RedHat pas encore prêt, attente supplémentaire..."
sleep 5

# ── Étape 2 : Installation des collections Ansible ────────────────────────────
info "Étape 2/4 — Installation des collections Ansible..."
ansible-galaxy collection install -r requirements.yml

# ── Étape 3 : Vérification de l'inventaire ────────────────────────────────────
info "Étape 3/4 — Test de connectivité Ansible (ping)..."
ansible wordpress_servers -i inventory.ini -m ping || error "Impossible de joindre les hôtes. Vérifiez les conteneurs."

# ── Étape 4 : Lancement du playbook ───────────────────────────────────────────
info "Étape 4/4 — Déploiement WordPress sur les deux machines..."
ansible-playbook -i inventory.ini site.yml -v

echo ""
echo "=============================================="
success "DÉPLOIEMENT TERMINÉ !"
echo "=============================================="
echo ""
echo -e "  ${GREEN}WordPress Debian${NC}  → http://localhost:8081"
echo -e "  ${GREEN}WordPress RedHat${NC}  → http://localhost:8082"
echo ""
echo -e "  Admin Debian → http://localhost:8081/wp-admin"
echo -e "  Admin RedHat → http://localhost:8082/wp-admin"
echo ""
echo -e "  Login    : admin"
echo -e "  Password : Admin_WP_2024!"
echo ""
